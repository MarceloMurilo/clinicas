package com.clinicas.model;

public enum StatusAgendamento {
    AGENDADO,
    CONFIRMADO,
    CANCELADO,
    REALIZADO,
    FALTOU
}
