package com.clinicas.model;

public enum Papel {
    PACIENTE,
    COORDENADOR,
    RECEPCIONISTA,
    ALUNO,
    PRECEPTOR,
    ADMIN
}
