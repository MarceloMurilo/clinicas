package com.clinicas.controller;

import com.clinicas.model.GradeHoraria;
import com.clinicas.repository.GradeHorariaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/grade")
@CrossOrigin(origins = "*")
public class GradeHorariaController {

    @Autowired
    private GradeHorariaRepository repository;

    @PostMapping
    public void salvarGrade(@RequestBody List<GradeHoraria> grade) {
        repository.deleteAll(); // Remove a grade anterior, se houver
        repository.saveAll(grade); // Salva a nova grade semanal
    }

    @GetMapping
    public List<GradeHoraria> listarGrade() {
        return repository.findAll();
    }
}
