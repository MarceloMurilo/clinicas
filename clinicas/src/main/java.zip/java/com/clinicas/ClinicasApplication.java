package com.clinicas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClinicasApplication {

	public static void main(String[] args) {
		SpringApplication.run(ClinicasApplication.class, args);
	}

}
